/*UPDATE*/

/*to update salary of employee=22,000 when salary is less than 22,000 and address of employee is bangalore*/
UPDATE EMPLOYEE
SET Salary=22000.00
WHERE Salary<22000.00 AND Address LIKE '%Bangalore%';

/*to update address of employee where employee id is 0563298007*/
UPDATE EMPLOYEE
SET Address='Gandhibazar,Bangalore'
WHERE EmpID='0563298007'; 

/*to twice value of number of units stored where number of units is between 14 and 21*/
UPDATE STORES
SET No_of_units=No_of_units*2
WHERE No_of_units BETWEEN 14 AND 21; 

/*to update drug inspector id equal to 66470251 when drug id in form '09'*/
UPDATE DRUG
SET Ins_ID='66470251'
WHERE DrugID LIKE'09__________'; 

/*to update phone number to 9845492977 when inspector id is 23119271*/
UPDATE DRUG_INSPECTOR
SET Phn_no='9845492977'
WHERE InsID='23119271';  

/*to update employee's designation equal to properator when gender is female and qualification is D.Pharma*/
UPDATE EMPLOYEE
SET Designation='Properator'
WHERE Sex='F' AND Qualification='D.Pharma'; 

/*to update employee's address to srinivas nagar, Bangalore when address is Gandhibazar and last name is nayak and phone number is 8962547313*/
UPDATE EMPLOYEE
SET Address='Srinivas Nagar,Bangalore'
WHERE Address='Gandhibazar,Bangalore' OR (Last_name='Nayak' OR  Phno='8962547313'); 

/*to update drug purpose to Type 2 Diabetes Mellitus when drug purpose is Type 2 Diabetes  */
UPDATE DRUG_PURPOSE
SET Purpose='Type 2 Diabetes Mellitus'
WHERE Purpose='Type 2 Diabetes';  

/*to update employee's phone number equal to 8169112338 when employee's id is 6973764687 and designation is QP */
UPDATE EMPLOYEE
SET Phno='8169112338'
WHERE EmpID='6973764687' AND Designation='QP';


/*DELETE*/

/*to delete tuple of employee with PUC qualification and gender is Female  */
DELETE FROM EMPLOYEE
WHERE Qualification LIKE '%PUC%' AND Sex='F';

/*to delete tuple of employee where last name of employee is Gowda and gender is Female */
DELETE FROM  EMPLOYEE
WHERE Last_name='Gowda' AND Sex='F';

/*to delete tuple of employee where address of employee is Gandhibazar*/
DELETE FROM EMPLOYEE
WHERE Address LIKE '%Gandhibazar%';

/*to delete tuple of stores where number of units is 1*/
DELETE FROM STORES
WHERE No_of_units=1;

/*to delete tuple of drug where category of drug is gel and composition contains Mometasone*/
DELETE FROM DRUG
WHERE Category='gel' AND Composition LIKE '%Mometasone%';

/*to delete tuple of drug purpose where purpose of drug is solve dryness*/
DELETE FROM DRUG_PURPOSE
WHERE Purpose LIKE '%Dry%';

/*to delete tuple of company location where location has string matching palace*/
DELETE FROM COMPANY_LOCATION
WHERE Clocation LIKE '%Palace%';

/*to delete tuple of drug purpose where drug id is 127360057254*/
DELETE FROM DRUG_PURPOSE
WHERE D_ID='127360057254';



