/*select names of all female employees*/
SELECT First_name,Midname,Last_name
FROM EMPLOYEE
WHERE Sex='F';

/*select id and salary of the manager of pharmacy which is located in "Ashok Nagar" */

SELECT  EmpID,Salary
FROM EMPLOYEE AS E,PHARMACY AS P
WHERE P.Location='Ashok Nagar' AND P.Mgr_ID=E.EmpID;

/* retrive all attributes of any employee who works in phramacy of id="8294250677" */

SELECT *
FROM EMPLOYEE
WHERE p_ID='8294250677';

/* list id and names of all the pharmacy which is either located in "Basavanagudi" or give orders to wholesaler whose id is "77082620" */

(SELECT DISTINCT PharmID,Pharma_name
FROM PHARMACY AS P
WHERE P.Location='Basavanagudi')
UNION
(SELECT DISTINCT PharmID,Pharma_name
FROM PHARMACY AS P,GIVE_ORDERS_TO AS G
WHERE G.W_ID='77082620' AND G.Pharma_ID=P.PharmID);

/* retrive all wholesaler whose address is in "Chikkaballapur"*/

SELECT Whname,WhID
FROM WHOLESALER
WHERE Address LIKE '%Chikkaballapur%';

/* retrieve all drug inspectors whose salary is in between 5000 and 25000 */
SELECT InsID,Ins_name,Ins_degree
FROM DRUG_INSPECTOR
WHERE Salary BETWEEN 5000 AND 25000;

/*list the drugs which is approved by the the drug inspector whose degree is m pharma*/
SELECT DrugID,Drug_name
FROM DRUG,DRUG_INSPECTOR
WHERE Ins_degree='M.Pharma' AND InsID=Ins_ID;

/*list all drug name,id and composition which is manufactured by the company whose id=484263 orderd alphabetically by name of the drug*/
SELECT DrugID,Drug_name,Composition
FROM DRUG
WHERE C_ID='484263'
ORDER BY Drug_name DESC;

