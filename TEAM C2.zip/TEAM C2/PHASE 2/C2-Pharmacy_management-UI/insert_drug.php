<!DOCTYPE html>
<html>
<head>
	<title>Insert Drug</title>
	<link rel="shortcut icon" href="icon.png">

<style>
	.box1
	{
		box-sizing:border-box;
		padding: 40px;
		width: 80%;
    	font-size: 15px;
		
	}

	h2
	{
		font-family: "Ink Free";
		font-size:30px;
		font-style:oblique;
	
		
	}
	
	body 
	{ 
  		background: url(back.jpg) no-repeat center center fixed; 
  		-webkit-background-size: cover;
  		-moz-background-size: cover;
  		-o-background-size: cover;
  		background-size: cover;
	}

	.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 5px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}

</style>

</head>

<body>
	
	<form action="insert_drug.php" method="POST">
		<p align="center" style="font-family:Century; margin-top:2px"><font size="6"><b>ADD NEW DRUG DETAILS HERE!</b></font></p>

	<div align="left">	
		<div class="box1" align="left">	
			
			&emsp;&emsp;<label><b>Drug Name</b>&emsp;<input type="text" name="name"  autofocus required></label> &emsp;&emsp; 
			<label><b>Category</b><input type="text" name="password_1" ></label>&emsp;&emsp; 
			<label><b>DrugID</b>&emsp;<input type="text" name="password_1" required></label><br></br>
			
			
			&emsp;&emsp;<label><b>Composition</b></label>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<label><b>Selling Price</b><input type="text" name="password_1"></label>&emsp;&emsp;
			<label><b>Bought Price</b>&emsp;<input type="text" name="password_1" ></label></br>
			&emsp;&emsp;<textarea rows="5" cols="30" placeholder="Composition"></textarea></label><br><br><br>

			&emsp;&emsp;<label><b>Manufacture Date</b>&emsp;<input type="text" name="name"  autofocus required></label> &emsp;&emsp; 
			<label><b>Expiry Date</b><input type="text" name="password_1" required></label>&emsp;&emsp; 
			<label><b>Approval Date</b>&emsp;<input type="text" name="password_1"></label><br></br>
			

			&emsp;&emsp;<label><b>Manufacturer ID&emsp;</b><input type="text" name="password_1" required></label>&emsp;&emsp; 
			<label><b>Drug Inspector ID</b>&emsp;<input type="text" name="password_1" required></label><br></br>

		<br></br><br>


			&emsp;&emsp;<button type="submit" class="book" name="reg_user">Save</button>
		</div>
	</div>	
			
		
	