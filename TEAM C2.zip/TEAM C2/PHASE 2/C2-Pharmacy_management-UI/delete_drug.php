<!DOCTYPE html>
<html>
<head>
	<title>Delete Drug</title>
	<link rel="shortcut icon" href="icon.png">

<style>
	.box1
	{
		box-sizing:border-box;
		padding: 40px;
		width: 80%;
    	font-size: 15px;
		
	}

	h2
	{
		font-family: "Ink Free";
		font-size:30px;
		font-style:oblique;
	
		
	}
	
	body 
	{ 
  		background: url(back.jpg) no-repeat center center fixed; 
  		-webkit-background-size: cover;
  		-moz-background-size: cover;
  		-o-background-size: cover;
  		background-size: cover;
	}

	.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 5px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}

</style>

</head>

<body>
	<!--<h1 align="center" style="font-family:Segoe Print"><font size="15" color="#CB4335"><i>Itzz Showtime</i></font></h2>
	<h2 align="center">Meet your next favourite MOVIE!!</h2>-->
	<!--<img src="itzz_showtime_final.jpg" height="65px" width="65px"/>-->
	<form action="insert_emp.php" method="POST">
		<p align="center" style="font-family:Century; margin-top:2px"><font size="6"><b>DELETE DRUG DETAILS HERE!</b></font></p>

	<div align="left">	
		<div class="box1" align="left">	
			
			
			<label><b>DrugID </b><input type="text" name="username" placeholder="eg: 012345678901" required></label></br></br></br>


			<label><b>Composition </label> </br></br><textarea rows="3" cols="30" placeholder="Composition" required></textarea></label><br><br><br>

			<label><b>Category</b>
			<select>
				<option>Tablet</option>
				<option>Syrup</option>
				<option>Drops</option>
				<option>Gel</option>
				<option>Capsule</option>
				<option>Machine</option>
				<option>Shampoo</option>
				<option>Machine</option>
				<option>Powder</option>
				<option>Injection</option>
				<option>Inhaler</option>
				<option>Soap</option>
				<option>Paste</option>
				<option>Respule</option>
				<option>Cream</option>
				<option>Lotion</option>
				
			</select>
		</label></br></br></br></br>
	


		


			&emsp;&emsp;<button type="submit" class="book" name="reg_user">Delete</button>
		</div>
	</div>	
			
		
	