<!DOCTYPE html>
<html>
<head>
	<title>Delete Employee</title>
	<link rel="shortcut icon" href="icon.png">

<style>
	.box1
	{
		box-sizing:border-box;
		padding: 40px;
		width: 80%;
    	font-size: 15px;
		
	}

	h2
	{
		font-family: "Ink Free";
		font-size:30px;
		font-style:oblique;
	
		
	}
	
	body 
	{ 
  		background: url(back.jpg) no-repeat center center fixed; 
  		-webkit-background-size: cover;
  		-moz-background-size: cover;
  		-o-background-size: cover;
  		background-size: cover;
	}

	.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 5px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}

</style>

</head>

<body>
	<!--<h1 align="center" style="font-family:Segoe Print"><font size="15" color="#CB4335"><i>Itzz Showtime</i></font></h2>
	<h2 align="center">Meet your next favourite MOVIE!!</h2>-->
	<!--<img src="itzz_showtime_final.jpg" height="65px" width="65px"/>-->
	<form action="insert_emp.php" method="POST">
		<p align="center" style="font-family:Century; margin-top:2px"><font size="6"><b>DELETE EMPLOYEE DETAILS HERE!</b></font></p>

	<div align="left">	
		<div class="box1" align="left">	
			
			
			<label><b>EmployeeID</b><input type="text" name="username" placeholder="eg: 0123456789" required></label></br></br></br>
			<label><b>Qualification</b>
			<select>
				<option>M.Pharma</option>
				<option>B.Pharma</option>
				<option>D.Pharma</option>
				<option>2nd PUC</option>
				
			</select></br></br></br>
	


		<label><b>Sex</b>
			<input type="radio" name="Plan">M
			<input type="radio" name="Plan">F
			<input type="radio" name="Plan">Others
		</label>
		<br></br><br></br>


			&emsp;&emsp;<button type="submit" class="book" name="reg_user">Delete</button>
		</div>
	</div>	
			
		
	