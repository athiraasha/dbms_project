<!DOCTYPE html>
<html>
<head>
	<title>Update Employee</title>
	<link rel="shortcut icon" href="icon.png">

<style>
	.box1
	{
		box-sizing:border-box;
		padding: 40px;
		width: 80%;
    	font-size: 15px;
		
	}

	h2
	{
		font-family: "Ink Free";
		font-size:30px;
		font-style:oblique;
	
		
	}
	
	body 
	{ 
  		background: url(back.jpg) no-repeat center center fixed; 
  		-webkit-background-size: cover;
  		-moz-background-size: cover;
  		-o-background-size: cover;
  		background-size: cover;
	}

	.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 5px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}

</style>

</head>

<body>
	<!--<h1 align="center" style="font-family:Segoe Print"><font size="15" color="#CB4335"><i>Itzz Showtime</i></font></h2>
	<h2 align="center">Meet your next favourite MOVIE!!</h2>-->
	<!--<img src="itzz_showtime_final.jpg" height="65px" width="65px"/>-->
	<form action="update_emp.php" method="POST">
		<p align="center" style="font-family:Century; margin-top:2px"><font size="6"><b>UPDATE EMPLOYEE SALARY </b></font></p>

	<div align="left">	
		<div class="box1" align="left">	
			 <label><b>EmployeeID   </b><input type="text" name="username" placeholder="eg: 0123456789" required></label></br></br>
			
			<label><b>Address</b>&emsp;
			<select>
				<option>Mysore</option>
				<option>Bangalore</option>
				<option>Tumkur</option>
				<option>Mangalore</option>
				<option>Hubli</option>
				<option>Dharwad</option>
				
			</select>
			</label><br></br>

			<label><b>Current Salary</b>&emsp;
			<select>
				<option> more than 20,000.00</option>
				<option>less than 20,000.00</option>
				<option>20,000</option>
				
				
			</select>
			</label><br></br>

			<label><b>Salary Update   </b><input type="text" name="username" placeholder="salary" required></label></br></br>
			

		&emsp;&emsp;
		<br></br><br>


			&emsp;&emsp;<button type="submit" class="book" name="reg_user">update</button>
		</div>
	</div>	
			
		
	