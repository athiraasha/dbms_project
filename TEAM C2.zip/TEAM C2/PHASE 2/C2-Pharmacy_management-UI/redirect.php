<!DOCTYPE html>
<html>
<head>
<title>redirect</title>
<link rel="shortcut icon" href="icon.png">

<script type="text/javascript">
/* <![CDATA[ */
function sub() {
window.location.href = site;
}
function goTo(URL) {
site = URL;
} 
/* ]]> */
</script>

<style>

  body 
  { 
      background: url(back.jpg) no-repeat center center fixed; 
      -webkit-background-size: cover;
      -moz-background-size: cover;
      -o-background-size: cover;
      background-size: cover;
    
  }
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}

* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; 
  /*display: flex;
  -ms-flex-wrap: wrap; */
  flex-wrap: wrap;
  margin: 0 -16px;
  align-items: left;
  padding: 10px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;

}

.col-25,
.col-50,
.col-75 {
  padding: 0 10px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
  width: 500px;
  height: 400px;
}

input[type=text] {
  width: 50%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}
.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;

}


.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 50%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}


@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>
</head>
<body>

<h2 align="left" style="font-family: Century"><b>&emsp;&emsp;SELECT MODE OF OPERATION</b></h2>
<br><br>
<div class="row" align="left" style="margin-left: 5px">
  <div class="col-75">
    <div class="container"><br>
      
      
        <div class="row">
          
          <div class="col-75">
        
           <div>
    <h3 align="left">
      &emsp;<input type=radio name="site" onchange="if(this.checked){goTo('insert_emp.php')}"/>
      Insert into EMPLOYEE</h3>
  </div>
            
  <div>
    <h3 align="left">
      &emsp;<input type=radio name="site" onchange="if(this.checked){goTo('Insert_drug.php')}"/>
      Insert into DRUG</h3>
  </div>
  <div>
    <h3 align="left">
      &emsp;<input type=radio name="site" onchange="if(this.checked){goTo('updateemp.php')}"/>
      Update EMPLOYEE</h3>
  </div>

  <div>
    <h3 align="left">
      &emsp;<input type=radio name="site" onchange="if(this.checked){goTo('update_stores.php')}"/>
      Update STORES</h3>
  </div>

  <div>
    <h3 align="left">
      &emsp;<input type=radio name="site" onchange="if(this.checked){goTo('delete_emp.php')}"/>
      Delete from EMPLOYEE</h3>
  </div>

  <div>
    <h3 align="left">
      &emsp;<input type=radio name="site" onchange="if(this.checked){goTo('delete_drug.php')}"/>
    Delete from DRUG</h3>
  </div>
    
      <input type="submit" value="Continue" class="btn" onclick="sub()">

            <div class="row">
             
              
            </div>
            <br><br>
            
          </div>
          
        </div>
        
    </div>
  </div>
  
  <div class="col-25">
   
  </div>
</div>

</body>
</html>
