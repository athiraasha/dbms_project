<!DOCTYPE html>
<html>
<head>
	<title>Insert Employee</title>
	<link rel="shortcut icon" href="icon.png">

<style>
	.box1
	{
		box-sizing:border-box;
		padding: 40px;
		width: 80%;
    	font-size: 15px;
		
	}

	h2
	{
		font-family: "Ink Free";
		font-size:30px;
		font-style:oblique;
	
		
	}
	
	body 
	{ 
  		background: url(back.jpg) no-repeat center center fixed; 
  		-webkit-background-size: cover;
  		-moz-background-size: cover;
  		-o-background-size: cover;
  		background-size: cover;
	}

	.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 5px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}

</style>

</head>

<body>
	
	<form action="insert_emp.php" method="POST">
		<p align="center" style="font-family:Century; margin-top:2px"><font size="6"><b>ADD NEW EMPLOYEE DETAILS HERE!</b></font></p>

	<div align="left">	
		<div class="box1" align="left">	
			
			&emsp;&emsp;<label><b>First Name</b>&emsp;<input type="text" name="name"  autofocus required></label> &emsp;&emsp; 
			<label><b>Middle Name</b><input type="text" name="password_1" ></label>&emsp;&emsp; 
			<label><b>Last Name</b>&emsp;<input type="text" name="password_1" required></label><br></br>
			&emsp;&emsp;<label><b>EmployeeID</b><input type="text" name="username" placeholder="eg: 0123456789" required></label>&emsp;&emsp;&emsp;
			<label><b>Qualification</b>
			<select>
				<option>M.Pharma</option>
				<option>B.Pharma</option>
				<option>D.Pharma</option>
				<option>2nd PUC</option>
				
			</select>
		</label> &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
			<label><b>Designation</b>&emsp;
			<select>
				<option>Properator</option>
				<option>QP</option>
				<option>Owner1</option>
				<option>Owner2</option>
				<option>Worker</option>
			</select>
		</label><br></br>
			&emsp;&emsp;<label><b>Address</b></label>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<label><b>Phone no</b>&emsp;<input type="text" name="password_1" ></label>&emsp;&emsp;&emsp;
			<label><b>Salary</b>&emsp;<input type="text" name="password_1" required ></label><br>&emsp;&emsp;
			<textarea rows="5" cols="30" placeholder="Address"></textarea></label><br><br><br>
			&emsp;&emsp;<label><b>PharmacyID</b>&emsp;<input type="text" name="password_1" placeholder="eg: 0123456789" ></label><br></br>


		&emsp;&emsp;<label><b>Sex</b>
			<input type="radio" name="Plan">M
			<input type="radio" name="Plan">F
			<input type="radio" name="Plan">Others
		</label>
		<br></br><br>


			&emsp;&emsp;<button type="submit" class="book" name="reg_user">Save</button>
		</div>
	</div>	
			
		
	