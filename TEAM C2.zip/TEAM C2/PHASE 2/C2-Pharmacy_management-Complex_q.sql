/*List out the drug names approved by Omkareshwar or Yashodha*/

SELECT Drug_name
FROM DRUG
WHERE DrugID IN
		(SELECT DrugID
		FROM DRUG AS D,DRUG_INSPECTOR AS I
		WHERE D.Ins_ID=I.InsID AND Ins_name='Omkareshwar')

		OR

	DrugID IN 
		(SELECT DrugID
		FROM DRUG AS D,DRUG_INSPECTOR AS I
		WHERE D.Ins_ID=I.InsID AND Ins_name='Yashodha');


/*List all the Drugs in Gururaja Pharmacy and their respective Manufacturer names*/


SELECT D.Drug_name,M.Name
FROM DRUG AS D, MANUFACTURER AS M, PHARMACY AS P,STORES AS S, DRUG_INSPECTOR AS I
WHERE D.C_ID=M.CompanyID AND P.Pharma_name='Gururaja Pharmacy' AND S.Ph_ID=P.PharmID AND S.D_ID=D.DrugID
GROUP BY D.Drug_name, M.Name;

/*For each Manufacturing company manufacturing more than 3 drugs, retrieve the company ID,Company name*/

SELECT CompanyID, M.name
FROM DRUG AS D,MANUFACTURER AS M
WHERE D.C_ID=M.CompanyID
GROUP BY CompanyID, M.name
HAVING COUNT(*)>3;

/* Retireve the drug names in Mallige Pharmacy approved by the drug inspector whose id= '91458839'*/

SELECT D.Drug_name
FROM DRUG AS D, MANUFACTURER AS M, PHARMACY AS P,STORES AS S, DRUG_INSPECTOR AS I
WHERE D.C_ID=M.CompanyID AND P.Pharma_name='Mallige Pharmacy' AND S.Ph_ID=P.PharmID AND S.D_ID=D.DrugID AND I.InsID=D.Ins_ID
GROUP BY D.Drug_name, M.Name, D.Ins_ID
HAVING D.Ins_ID='91458839';

/* Retrieve phone numbers of employee, works in pharmacy gives orders to wholesaler of id 77082620 */

SELECT Phno
FROM EMPLOYEE
WHERE p_ID IN 	(SELECT Pharma_ID
				 FROM GIVE_ORDERS_TO
				 WHERE  W_ID 
					IN
				 (SELECT WhID
				 FROM WHOLESALER
				 WHERE WhID='77082620'));

/* To get salary of drug insector where the drug purpose is asthma */

SELECT Salary
FROM DRUG_INSPECTOR
WHERE EXISTS (SELECT	*
				FROM 	DRUG
				WHERE EXISTS(SELECT *
							FROM DRUG_PURPOSE
							WHERE Purpose='Asthma'));



/* To get address of manager of pharmacy which stores 30 or 35 number of units drugs*/

SELECT Address
FROM EMPLOYEE
WHERE EmpID IN(SELECT Mgr_ID
				FROM PHARMACY
				WHERE Mgr_ID=EmpID AND PharmID IN (SELECT Ph_ID
													FROM STORES
													WHERE No_of_units IN (30,35)));

/* Companay name of manufacturers of drugs where drugs are purchased by wholesaler to whom apollo pharmacy gave orders*/

SELECT Name
FROM MANUFACTURER
WHERE CompanyID IN (SELECT C_ID
					FROM PURCHASES_FROM
					WHERE Wh_Id IN (
									SELECT W_ID
									FROM GIVE_ORDERS_TO
									WHERE Pharma_ID IN (SELECT PharmID
														FROM PHARMACY
														WHERE Pharma_name='Apollo Pharmacy')));												
				
				
/*for each pharmacy that has more than three employees retireve pharmacy id and number of employees whose salary is greater than 30000*/

SELECT p_ID,COUNT(*)
FROM EMPLOYEE
WHERE Salary>30000 AND p_ID IN
      (SELECT p_ID
       FROM EMPLOYEE
GROUP BY p_ID
       HAVING COUNT(*)>3)
GROUP BY p_ID;


/*what is the sum,minimum and maximum value of the salary of the employees working in the pharmacy which is located in Ashok Nagar*/
SELECT SUM(Salary),MAX(Salary),Min(Salary)
FROM EMPLOYEE,PHARMACY
WHERE Location='Ashok Nagar' AND p_ID=PharmID;

/*list names of the pharmcy that gives orders to atleast three wholesalers*/

SELECT PharmID
FROM PHARMACY
WHERE EXISTS (SELECT Pharma_ID,COUNT(*)
              FROM GIVE_ORDERS_TO
              WHERE PharmID=Pharma_ID 
	      GROUP BY Pharma_ID
	      HAVING COUNT(*)>=3);
             
/*list all the employee names and the name of the pharmacy they manage if they happen to manage a pharamcy.if they do not manage one just indicate using null values*/

SELECT First_name,Midname,Last_name,Pharma_name
FROM (EMPLOYEE  LEFT OUTER JOIN PHARMACY ON EmpID=Mgr_ID);









		
